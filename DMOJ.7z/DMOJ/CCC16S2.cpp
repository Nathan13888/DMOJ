#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int Q, N;
    cin >> Q >> N;
    int dmo[N], peg[N];
    sort(dmo, dmo + N);
    sort(peg, peg + N);
    if (Q == 1)
    {
    }
    else
    {
    }

    return 0;
}