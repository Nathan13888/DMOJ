#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    double n1, n2;
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    cin >> n >> n1 >> n2;
    printf("%.9f\n", -n2 / n1 / n);
}