#include <bits/stdc++.h>

using namespace std;

int main()
{
    cout << true + true;
    ios_base::sync_with_stdio(false);
    cout << (char)0x48 << (char)0x65 << (char)0x6C << (char)0x6C << (char)0x6F << (char)0x2C
         << (char)0x20 << (char)0x57 << (char)0x6F << (char)0x72 << (char)0x6C << (char)0x64 << (char)0x21;
}
